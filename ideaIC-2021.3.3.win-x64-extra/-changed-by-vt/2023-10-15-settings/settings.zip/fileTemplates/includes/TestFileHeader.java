/**
* Tests for {@link xxx}.
*
* @author lei.liu
* @since ${YEAR}-${MONTH}-${DAY}
*/