#parse("TestFileHeader.java")

public class ${NAME} {
  ${BODY}
}