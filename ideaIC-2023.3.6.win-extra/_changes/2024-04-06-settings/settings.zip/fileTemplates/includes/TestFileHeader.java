/**
* Tests for {@link ${NAME}}.
*
* @author lei.liu
* @since ${YEAR}-${MONTH}-${DAY}
*/